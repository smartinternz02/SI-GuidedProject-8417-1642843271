package com.demian.SpringApiTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApiTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
